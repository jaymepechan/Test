﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Test
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            RegistryKey registryKey;
            string str;
            Log("Start USD Program BootStrap", TraceEventType.Verbose);
            try
            {
                Log("START: Open Software\\Microsoft\\Internet Explorer\\Main", TraceEventType.Verbose);
                RegistryKey registryKey1 = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Internet Explorer\\Main", true);
                Log("Success: Open Software\\Microsoft\\Internet Explorer\\Main", TraceEventType.Verbose);
                if (registryKey1.GetValue("Cleanup HTCs") == null)
                {
                    Log("START: Set Value Cleanup HTCs", TraceEventType.Verbose);
                    registryKey1.SetValue("Cleanup HTCs", "yes", RegistryValueKind.String);
                    Log("Success: Set Value Cleanup HTCs", TraceEventType.Verbose);
                }
                registryKey1.Close();
                object value = 0;
                try
                {
                    Log("START: Open Software\\Policies\\Microsoft\\Windows\\CurrentVersion\\Internet Settings ", TraceEventType.Verbose);
                    RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey("Software\\Policies\\Microsoft\\Windows\\CurrentVersion\\Internet Settings", false);
                    Log("SUCCESS: Open Software\\Policies\\Microsoft\\Windows\\CurrentVersion\\Internet Settings ", TraceEventType.Verbose);
                    Log("START: SEC_HKLM_only", TraceEventType.Verbose);
                    value = registryKey2.GetValue("Security_HKLM_only");
                    Log("START: SEC_HKLM_only", TraceEventType.Verbose);
                    registryKey2.Close();
                }
                catch
                {
                }
                registryKey = (value == null || (int)value != 1 ? Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Internet Explorer", true) : Registry.LocalMachine.OpenSubKey("Software\\Microsoft\\Internet Explorer", true));
                if (registryKey != null)
                {
                    Log("START:Create Main", TraceEventType.Verbose);
                    RegistryKey registryKey3 = registryKey.OpenSubKey("Main", true) ?? registryKey.CreateSubKey("Main");
                    Log("Success:Create Main", TraceEventType.Verbose);
                    Log("START:Create Feature Control", TraceEventType.Verbose);
                    RegistryKey registryKey4 = registryKey3.OpenSubKey("FeatureControl", true) ?? registryKey3.CreateSubKey("FeatureControl");
                    Log("Success:Create Feature Control", TraceEventType.Verbose);
                    Log("START:Create FEATURE_ADDITIONAL_IE8_MEMORY_CLEANUP", TraceEventType.Verbose);
                    RegistryKey registryKey5 = registryKey4.OpenSubKey("FEATURE_ADDITIONAL_IE8_MEMORY_CLEANUP", true) ?? registryKey4.CreateSubKey("FEATURE_ADDITIONAL_IE8_MEMORY_CLEANUP");
                    Log("Success:Create FEATURE_ADDITIONAL_IE8_MEMORY_CLEANUP", TraceEventType.Verbose);
                    registryKey4.Close();
                    string location = Assembly.GetExecutingAssembly().Location;
                    string fileName = "Test.exe";
                    Log("START:Create" +fileName, TraceEventType.Verbose);
                    if (registryKey5.GetValue(fileName) == null)
                    {
                        registryKey5.SetValue(fileName, 1, RegistryValueKind.DWord);
                    }
                    Log("SUCCESS:Create" + fileName, TraceEventType.Verbose);
                    fileName = "Test";
                    fileName = string.Concat(fileName, ".vshost.exe");
                    if (registryKey5.GetValue(fileName) == null)
                    {
                        Log("START:Create" + fileName, TraceEventType.Verbose);
                        registryKey5.SetValue(fileName, 1, RegistryValueKind.DWord);
                        Log("SUCCESS:Create" + fileName, TraceEventType.Verbose);
                    }
                    registryKey5.Close();
                    registryKey3.Close();
                    registryKey.Close();
                    EnableBrowserEmulation();
                }
            }
            catch (Exception ex)
            {
                this.errors.Text = ex.Message + Environment.NewLine + ex.StackTrace;
            }
        }


        private void Log(string p, TraceEventType traceEventType)
        {
            this.logs.Text += p +Environment.NewLine;
        }


        private static void EnableBrowserEmulation()
        {
            try
            {
                Version eVersion = Util.GetIEVersion();
                int num = -1;
                if (eVersion != null)
                {
                    switch (eVersion.Major)
                    {
                        case 8:
                            {
                                num = 8888;
                                break;
                            }
                        case 9:
                            {
                                num = 9999;
                                break;
                            }
                        case 10:
                            {
                                num = 10001;
                                break;
                            }
                        default:
                            {
                                if (eVersion.Major < 11)
                                {
                                    break;
                                }
                                num = 10001;
                                break;
                            }
                    }
                }
                if (num > 0)
                {
                    RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Internet Explorer", true);
                    if (registryKey != null)
                    {
                        RegistryKey registryKey1 = registryKey.OpenSubKey("Main", true) ?? registryKey.CreateSubKey("Main");
                        RegistryKey registryKey2 = registryKey1.OpenSubKey("FeatureControl", true) ?? registryKey1.CreateSubKey("FeatureControl");
                        RegistryKey registryKey3 = registryKey2.OpenSubKey("FEATURE_BROWSER_EMULATION", true) ?? registryKey2.CreateSubKey("FEATURE_BROWSER_EMULATION");
                        string fileName = "Test.exe";
                        if (registryKey3.GetValue(fileName) == null)
                        {
                            registryKey3.SetValue(fileName, num, RegistryValueKind.DWord);
                        }
                        registryKey2.Close();
                        registryKey3.Close();
                        registryKey1.Close();
                        registryKey.Close();
                    }
                }
            }
            catch (Exception exception)
            {
              
            }
        }
    }
}
