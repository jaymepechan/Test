﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test
{
    public class Util
    {
        private static Version _ieVersion;

        static Util()
        {
        }

        public Util()
        {
        }

        public static Version GetIEVersion()
        {
            Version version;
            Version version1;
            if (Util._ieVersion != null)
            {
                return Util._ieVersion;
            }
            try
            {
                RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("Software\\Microsoft\\Internet Explorer");
                if (registryKey != null)
                {
                    object value = registryKey.GetValue("Version");
                    if (value != null)
                    {
                        version = new Version((string)value);
                    }
                    else
                    {
                        version = null;
                    }
                    Util._ieVersion = version;
                    if (Util._ieVersion != null && Util._ieVersion.Major >= 9)
                    {
                        value = registryKey.GetValue("svcVersion");
                        if (value != null)
                        {
                            version1 = new Version((string)value);
                        }
                        else
                        {
                            version1 = null;
                        }
                        Version version2 = version1;
                        if (version2 != null)
                        {
                            Util._ieVersion = version2;
                        }
                    }
                    registryKey.Close();
                }
            }
            catch (Exception exception)
            {
                
            }
            return Util._ieVersion;
        }
    }
}
